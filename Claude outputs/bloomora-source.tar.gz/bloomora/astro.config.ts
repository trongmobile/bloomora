import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import { normalizeBase, normalizeSite } from './src/lib/url.ts';

/**
 * `SITE_URL` and `BASE_PATH` come from the environment so the same code builds for
 *  - a custom domain:        SITE_URL=https://flowers.example.com  BASE_PATH=/
 *  - a GitHub project site:  SITE_URL=https://<owner>.github.io    BASE_PATH=/<repo>/
 * See docs/DEPLOYMENT.md.
 */
const site = normalizeSite(process.env.SITE_URL);
const base = normalizeBase(process.env.BASE_PATH);

export default defineConfig({
  site,
  base,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory', inlineStylesheets: 'auto' },
  integrations: [react()],
  devToolbar: { enabled: false },
  compressHTML: true,
});
